#!/bin/bash
#tar -xzvf $1 
export LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH
chmod +x wdSetIdle3To5Min
./wdSetIdle3To5Min $1 $2


